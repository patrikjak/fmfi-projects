a = '7 3'

# print(int(a)) ValueError
# print(a()) TypeError
# print(open(a)) FileNotFoundError
# print(int(a[0])/0) ZeroDivisionError
# print("".a) AttributeError
# print(a+b) NameError
# assert isinstance(a, int) AssertionError
# print(float(int(a[0])**10000)) OverflowError
