def priemer(a, b):
    priemer = (a + b) / 2
    return priemer


print(priemer(1.25, 4))