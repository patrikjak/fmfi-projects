print((3 + 4) * 5 + 2 ** (100 // 5))
print(((3).__add__(4)).__mul__(5).__add__((2).__pow__((100).__floordiv__(5))))

print((7).__pow__(8).__str__().__len__().__add__('xy'.__rmul__(8).__len__().__add__(1)).__mul__(13))
print((len(str(7 ** 8)) + len("xy") * 8 + 1) * 13)
